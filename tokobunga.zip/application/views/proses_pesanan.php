<div class="container-fluid">
	<div class="alert alert-success">
		<p class="text-center align-middle">Selamat, Pesanan Anda Telah Berhasil diproses!!!</p>	
	</div>
</div>